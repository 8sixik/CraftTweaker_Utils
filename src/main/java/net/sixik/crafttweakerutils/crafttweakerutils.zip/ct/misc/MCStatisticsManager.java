package net.sixik.crafttweakerutils.ct.misc;

import com.blamejared.crafttweaker.api.annotation.ZenRegister;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.ServerStatsCounter;
import net.minecraft.stats.Stat;
import org.openzen.zencode.java.ZenCodeType;

@ZenRegister
@ZenCodeType.Name("mods.crafttweakerutils.misc.StatisticsManager")
public class MCStatisticsManager {

    private final ServerPlayer player;
    private final ServerStatsCounter playerStat;

    public MCStatisticsManager(ServerPlayer player) {
        this.player = player;
        this.playerStat = player.getStats();
    }

    public static MCStatisticsManager getPlayer(ServerPlayer sPlayer) {
        return new MCStatisticsManager(sPlayer);
    }

    @ZenCodeType.Method
    public int getValue(String stat) {
        if (Stat.getCustomCriteriaNames().contains(stat)) {
            return playerStat.getValue((Stat<?>) Stat.byName(stat).get());
        } else {
            return -1;
        }
    }

    @ZenCodeType.Method
    public int getValue(ResourceLocation stat) {
        if (Stat.getCustomCriteriaNames().contains(stat.getNamespace())) {
            return playerStat.getValue((Stat<?>) Stat.byName(stat.getNamespace()).get());
        } else {
            return -1;
        }
    }
}
